export interface Typing{
    from:string,
    message_status:string
}